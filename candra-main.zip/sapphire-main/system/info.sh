#!/bin/bash
clear
neofetch --ascii_distro mac
cat /root/log-install.txt
echo -e ""
read -n 1 -s -r -p "  Press any key to back on menu"
menu
esac
